<?php

$servername  = "localhost";
$username  = "root";
$password = "";
$db = "db_work";

$connect = new mysqli($servername , $username, $password, $db);
if ($connect->connect_error) {
    die("Error Connect to DB" . $connect->connect_error);
}

$name = "";
$email = "";
$phone = "";
$profession = "";
$company = "";


if($_SERVER['REQUEST_METHOD'] == 'GET'){

    if(!isset($_GET['id'])){
        header("location: ./table.php");
        exit;
    }

    $id = $_GET['id'];

    $sql = "SELECT * FROM tbluser WHERE id = $id";

    $result = $connect->query($sql);
    $row = $result->fetch_assoc();
    if (!$row) {
        die("Error Get Data ");
        header('location: ./table.php');
    }

    $name = $row['name'];
    $email = $row['email'];
    $phone = $row['phone'];
    $phone = $row['phone'];
    $profession= $row['profession'];
    $company = $row['company'];

}else{

    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $profession = $_POST["profession"];
    $company = $_POST["company"];
    $id = $_POST['id'];

    if($name == "" || $email =="" || $phone == "" || $profession == "" || $company == ""){

        echo "
            <script>
                alert('All Field Can Not Empty');
            </script>
        ";
        die();
    }

    $sql = "UPDATE tbluser SET name = '$name', email = '$email' , phone='$phone',profession='$profession',company='$company' WHERE id = $id";
    $result = $connect->query($sql);
    if (!$result) {
        echo  " <script>
            alert('Edit Not Success !');
        </script> ";
        die();
    }

    header("location: ./table.php");
    exit;



}



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        .container {
            width: 70%;
            margin: 5rem auto;
        }

        .head {
            background-color: gray;
            color: white;
        }

        button {
            padding: .5rem 1rem;
            cursor: pointer;
            border: none;
            color: white;
            border-radius: .2rem;
        }

        .edit {
            background-color: blue;
        }

        .delete {
            background-color: red;
        }

        .add {
            background-color: green;
            margin-bottom: 1rem;

        }

        a {
            color: white;
            text-decoration: none;
        }

        form {
            display: flex;
            flex-direction: column;
            width: 30rem;
            margin: auto;
        }

        input {
            padding: .5rem 2rem;
            margin-bottom: .5rem;
        }
    </style>

</head>
<body>

    <div class="container">
        <h1>Edit User</h1>

        <form method="POST">

            <input type="hidden" name="id" value="<?php echo $id; ?>" />
            <input placeholder="Name..." name="name" value="<?php echo $name; ?>" />
            <input placeholder="email..." name="email" value="<?php echo $email; ?>" />
            <input placeholder="phone..." name="phone" value="<?php echo $phone; ?>" />
            <input placeholder="profession..." name="profession" value="<?php echo $profession; ?>" />
            <input placeholder="company..." name="company" value="<?php echo $company; ?>" />
            <button class="edit" type="submit">Edit</button>

        </form>
        
    </div>
    
</body>
</html>