<?php

$servername = "localhost";
$username  = "root";
$password = "";
$db = "db_work";

$connect = new mysqli($servername, $username, $password, $db);
if ($connect->connect_error) {
    die("Error Connect to DB" . $connect->connect_error);
}

?>

<!DOCTYPE html>
<html>

<head>
    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        td,
        th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #dddddd;
        }

        .container {
            width: 70%;
            margin: 5rem auto;
        }

        .head {
            background-color: gray;
            color: white;
        }

        button {
            padding: .5rem 1rem;
            cursor: pointer;
            border: none;
            color: white;
            border-radius: .2rem;
        }

        .edit {
            background-color: blue;
        }

        .delete {
            background-color: red;
        }

        .add {
            background-color: green;
            margin-bottom: 1rem;

        }

        a {
            color: white;
            text-decoration: none;
        }
    </style>
</head>

<body>


    <div class="container">
        <h2>Php CRUD</h2>

        <button class="add"><a href="./add.php">Add</a></button>
        <table>
            <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Profession</th>
                    <th>Company</th>
                    <th>Action</th>
            </tr>

            <?php

            $sql = "SELECT * FROM tbluser";
            $result = $connect->query($sql);

            if (!$result) {
                die("Error Get Data");
            }

            while ($row = $result->fetch_assoc()) {
                echo "

                <tr>
                <td>$row[id]</td>
                <td>$row[name]</td>
                <td>$row[email]</td>
                <td>$row[phone]</td>
                <td>$row[profession]</td>
                <td>$row[company]</td>
                <td>
                      <button class='edit'><a href='./edit.php?id=$row[id]'>Edit</a></button>
                      <button class='delete'><a href='./delete.php?id=$row[id]'>Delete</a></button>
                </td>
                </tr>

            ";
            }
            ?>

        </table>
    </div>

</body>

</html>