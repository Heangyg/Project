<?php
    $servername = "localhost";
    $username = "root";
    $password ="";
    $db = "db_work";
    $con = new mysqli($servername, $username, $password, $db);

    if($con->connect_error){
        die("Connection faild: ".$con->connect_error);
    }
    echo "Connection successfully";

   // jqury

//    $fname = $_POST['fname'];
//    $password = $_POST['password'];

//     $sql = "INSERT INTO users (fname,password) v
//     VALUES ('$fname','$password')";
    
//     echo $sql;

//     $conn->close();
?>