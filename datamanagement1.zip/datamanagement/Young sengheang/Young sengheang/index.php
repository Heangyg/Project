<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form name="form1" action="./table.php" onsubmit="return validate()"  method="$_POST">
        name:
        <input type="text" name="fname"><br>
        Password:
        <input type="password" name="password"><br>
        <input type="submit" value="submit">
    </form>
    <script>
        function validate(){
            //Get form data
            let name = document.forms["form1"]["fname"].value;
            let password = document.forms["form1"]["password"].value;

            //check form data
            if(name == "")alert("please provide name!");
            if(password == "")alert("please provide password!");

            if((name == "") || (password == ""))return false;

            //return 
            return true;

        }
    </script>
</body>
</html>