<?php

$servername = "localhost";
$username  = "root";
$password = "";
$db = "db_work";

$connect = new mysqli($servername, $username, $password, $db);
if ($connect->connect_error) {
    die("Error Connect to DB" . $connect->connect_error);
}

if(isset($_GET['id'])){
    $id = $_GET['id'];

    $sql = "DELETE FROM tbluser WHERE id=$id";
    $connect->query($sql);
}

header('location: ./table.php');
exit;


?>