
   <!-- // echo "hello"."<br/>";
   // echo $_GET['name']."<br/>";
   // echo $_GET['password']."<br/>"; -->
