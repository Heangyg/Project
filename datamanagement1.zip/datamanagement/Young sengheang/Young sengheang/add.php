<?php

$servername = "localhost";
$username  = "root";
$password = "";
$db = "db_login";

$connect = new mysqli($servername, $username, $password, $db);
if ($connect->connect_error) {
    die("Error Connect to DB" . $connect->connect_error);
}
$id = "";
$name = "";
$email = "";
$phone = "";
$profession = "";
$company = "";

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $profession = $_POST['profession'];
    $company = $_POST['company'];
   

    if($id == "" || $name == "" || $email =="" || $phone == "" || $profession == "" || $company == "" ){

        echo "
            <script>
                alert('All Field Can Not Empty');
            </script>
        ";
    }


    $sql = "INSERT INTO tblProduct (id,name,email,phone,profession,company) VALUES ('$id', $name', '$email', '$phone', '$profession', '$company')";

    $result = $connect->query($sql);
    if (!$result) {
        die("Error Add Data");
    }

    header('location: ./data.php');
    exit;
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        .container {
            width: 70%;
            margin: 5rem auto;
        }

        .head {
            background-color: gray;
            color: white;
        }

        button {
            padding: .5rem 1rem;
            cursor: pointer;
            border: none;
            color: white;
            border-radius: .2rem;
        }

        .edit {
            background-color: blue;
        }

        .delete {
            background-color: red;
        }

        .add {
            background-color: green;
            margin-bottom: 1rem;

        }

        a {
            color: white;
            text-decoration: none;
        }

        form {
            display: flex;
            flex-direction: column;
            width: 30rem;
            margin: auto;
        }

        input {
            padding: .5rem 2rem;
            margin-bottom: .5rem;
        }
    </style>

</head>
<body>

    <div class="container">
        <h1>Add User</h1>

        <form method="POST">

            <input placeholder="Name..." name="name" value="" />
            <input placeholder="email..." name="email" value="" />
            <input placeholder="phone..." name="phone" value="" />
            <input placeholder="profession..." name="profession" value="" />
            <input placeholder="company..." name="company" value="" />
            <button class="add" type="submit">Add</button>

        </form>
        
    </div>
    
</body>
</html> 